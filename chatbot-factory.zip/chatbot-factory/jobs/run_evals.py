"""Run golden-set evals and apply the combined gate (EVG-1..5, EVL-6, CAS-4).

--bot_id X       one bot (candidate release by default; after doc/config changes, EVL-6)
--bot_id all     every non-draft bot (platform release gate in dev, CAS-4)
--channel live   evaluate the live release instead (post-promotion smoke test, REL-11)
--limit N        only the first N approved questions (smoke test)
"""
import json
import os
import time
import uuid

import mlflow
from _bootstrap import args, context

from factory import PLATFORM_VERSION, evals, llm
from factory.ingestion import BotPaths
from factory.releases import index_table

a = args("catalog", "bot_id", "trigger", "channel", "limit")
spark, sql, settings, cp, w = context(a.catalog)
client = llm.openai_client(w)
agent_ep = settings.get("agent.serving_endpoint")
judge_ep = settings.get("models.judge_endpoint")
thresholds = settings.thresholds()
zero_checks = settings.get("quality.zero_failure_checks", [])
min_cases = int(settings.get("quality.min_golden_questions", 50))
mlflow.set_experiment("/Shared/chatbot-factory/evals")
git_commit = os.environ.get("FACTORY_GIT_COMMIT", "")

bots = [b for b in cp.list_bots() if b["state"] not in ("draft", "provisioning")] \
    if a.bot_id in ("", "all") else [cp.get_bot(a.bot_id)]

for bot in bots:
    cfg = cp.get_config(bot["bot_id"])
    channel = a.channel or ("candidate" if bot.get("candidate_release_id") else "live")
    release_id = bot.get("candidate_release_id") if channel == "candidate" else bot.get("live_release_id")
    if not release_id:
        print(f"{cfg.bot_id}: no {channel} release to evaluate")
        continue
    p = BotPaths(settings, cfg.bot_id)
    flag = "in_candidate" if channel == "candidate" else "in_live"
    now = int(time.time())
    allowed = {r["chunk_id"] for r in sql.query(
        f"""SELECT chunk_id FROM {index_table(settings, cfg)} WHERE bot_id = :b AND {flag}
            AND effective_ts <= :n AND expires_ts > :n""", {"b": cfg.bot_id, "n": now})}
    cases = sql.query(f"SELECT * FROM {p.t('golden_set')} WHERE approved AND active "
                      "AND kind IN ('in_scope', 'out_of_scope', 'feedback') ORDER BY difficulty, eval_id")
    if a.limit:
        cases = [c for c in cases if c["kind"] == "in_scope"][: int(a.limit)]
    results, chunk_cache = [], {}
    for case in cases:
        try:
            response, custom = evals.call_agent(client, agent_ep, cfg.bot_id, case["question"], channel)
        except Exception as e:  # noqa: BLE001
            response, custom = f"ERROR: {e}", {"outcome": "error"}
        needed = [c["chunk_id"] for c in custom.get("citations", []) if c["chunk_id"] not in chunk_cache]
        if needed:
            rows = sql.query(
                f"SELECT chunk_id, chunk_to_retrieve FROM {p.t('chunked')} WHERE chunk_id IN "
                f"({', '.join(f':c{i}' for i in range(len(needed)))})",
                {f"c{i}": c for i, c in enumerate(needed)})
            chunk_cache.update({r["chunk_id"]: r["chunk_to_retrieve"] for r in rows})
        results.append(evals.score_case(client, judge_ep, case, response, custom, chunk_cache, allowed))

    metrics = evals.aggregate(results)
    zero = evals.failure_counts(results)
    rel = sql.query(f"SELECT safety_override_by FROM {settings.fq('releases')} WHERE release_id = :r",
                    {"r": release_id})
    override = bool(rel and rel[0]["safety_override_by"])
    n_in_scope = sum(1 for c in cases if c["kind"] == "in_scope")
    gate = evals.gate(metrics, thresholds, zero, zero_checks, n_in_scope,
                      1 if a.limit else min_cases, override)
    run_id = str(uuid.uuid4())
    with mlflow.start_run(run_name=f"{cfg.bot_id}-{channel}-{a.trigger or 'manual'}"):
        mlflow.set_tags({"bot_id": cfg.bot_id, "release_id": release_id, "channel": channel,
                         "platform_version": PLATFORM_VERSION, "git_commit": git_commit,
                         "trigger": a.trigger or "manual", "passed": str(gate.passed)})
        mlflow.log_metrics(metrics)
        mlflow.log_metrics({f"failures_{k}": v for k, v in zero.items()})
        mlflow.log_table({
            "eval_id": [r.eval_id for r in results], "kind": [r.kind for r in results],
            "question": [r.question for r in results], "response": [r.response for r in results],
            "outcome": [r.outcome for r in results], "scores": [json.dumps(r.scores) for r in results],
            "failures": [json.dumps(r.failures) for r in results],
            "rationales": [json.dumps(r.rationales) for r in results],
        }, "results.json")
    sql.execute(
        f"""INSERT INTO {settings.fq('eval_runs')} VALUES (:id, :b, :rel, :ch, :t, :pv, :gc,
            CAST(:cv AS INT), :m, CAST(:p AS BOOLEAN), CAST(:nr AS BOOLEAN), current_timestamp())""",
        {"id": run_id, "b": cfg.bot_id, "rel": release_id, "ch": channel, "t": a.trigger or "manual",
         "pv": PLATFORM_VERSION, "gc": git_commit, "cv": bot["config_version"],
         "m": json.dumps({"metrics": metrics, "zero_failures": zero, "failures": gate.failures,
                          "n_cases": len(cases), "per_case": [
                              {"eval_id": r.eval_id, "question": r.question, "outcome": r.outcome,
                               "scores": r.scores, "failures": r.failures, "rationales": r.rationales}
                              for r in results]}),
         "p": gate.passed, "nr": gate.needs_safety_review})
    if channel == "candidate" and not a.limit:
        sql.execute(f"""UPDATE {settings.fq('releases')} SET eval_run_id = :e, eval_passed = CAST(:p AS BOOLEAN),
                        updated_at = current_timestamp() WHERE release_id = :r""",
                    {"e": run_id, "p": gate.passed, "r": release_id})
        cp.publish(cfg.bot_id)
    if not gate.passed and channel == "live" and not a.limit:
        cp.alert(cfg.bot_id, "eval_regression", "high", "; ".join(gate.failures),
                 dedupe_key=f"eval:{cfg.bot_id}:{release_id}:{PLATFORM_VERSION}")
    print(cfg.bot_id, channel, "PASSED" if gate.passed else "FAILED", metrics, zero, gate.failures)
    # Exit code lets the promote job treat a failed smoke test as a failure
    if a.limit and not gate.passed:
        raise SystemExit(f"Smoke test failed for {cfg.bot_id}: {gate.failures}")
