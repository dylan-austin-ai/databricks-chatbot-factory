"""Daily production monitoring (MON-4, MON-6, EVL-7).

1. Judge a sample of yesterday's answers: 20% by default (admin setting),
   100% for bots an admin flagged critical.
2. Alert owners and MLOps when a bot's 7-day pass rate drops below threshold.
3. Turn thumbs-down feedback into unapproved golden-set questions for review.
"""
import uuid

from _bootstrap import args, context

from factory import evals, llm
from factory.ingestion import BotPaths

a = args("catalog", "lookback_hours")
spark, sql, settings, cp, w = context(a.catalog)
client = llm.openai_client(w)
judge_ep = settings.get("models.judge_endpoint")
rate = float(settings.get("quality.judge_sample_rate", 0.2))
hours = int(a.lookback_hours or 24)

critical = {b["bot_id"] for b in cp.list_bots() if str(b.get("critical")).lower() == "true"}
rows = sql.query(
    f"""SELECT r.* FROM {settings.fq('request_log')} r
        LEFT ANTI JOIN {settings.fq('judge_results')} j ON j.request_id = r.request_id
        WHERE r.ts >= current_timestamp() - make_interval(0, 0, 0, 0, {hours}, 0, 0)
          AND r.outcome = 'answered' AND r.channel = 'live' AND NOT r.synthetic""")
sample = evals.sample_for_judging(rows, critical, rate)
print(f"Judging {len(sample)} of {len(rows)} answers (rate {rate:.0%}, critical: {sorted(critical)})")

for r in sample:
    p = BotPaths(settings, r["bot_id"])
    ids = list(r.get("cited_chunk_ids") or [])
    texts = []
    if ids:
        texts = [x["chunk_to_retrieve"] for x in sql.query(
            f"SELECT chunk_to_retrieve FROM {p.t('chunked')} WHERE chunk_id IN "
            f"({', '.join(f':c{i}' for i in range(len(ids)))})", {f"c{i}": c for i, c in enumerate(ids)})]
    scores = {
        "groundedness": evals.judge(client, judge_ep, "groundedness",
                                    context="\n---\n".join(texts), response=r["answer"]),
        "relevance": evals.judge(client, judge_ep, "relevance", question=r["question"],
                                 response=r["answer"]),
        "safety": evals.judge(client, judge_ep, "safety", response=r["answer"]),
        "citation_accuracy": evals.citation_accuracy(r["answer"], texts),
    }
    for name, (ok, why) in scores.items():
        sql.execute(f"INSERT INTO {settings.fq('judge_results')} VALUES "
                    "(:r, :b, :s, CAST(:v AS DOUBLE), :why, current_timestamp())",
                    {"r": r["request_id"], "b": r["bot_id"], "s": name, "v": 1.0 if ok else 0.0,
                     "why": why})

# Quality-drop alerts (MON-4)
thresholds = settings.thresholds()
for row in sql.query(f"""SELECT bot_id, scorer, avg(value) AS rate, count(*) AS n
                         FROM {settings.fq('judge_results')}
                         WHERE ts >= current_timestamp() - INTERVAL 7 DAYS
                         GROUP BY bot_id, scorer HAVING count(*) >= 10"""):
    t = thresholds.get(row["scorer"])
    if t and float(row["rate"]) < t:
        cp.alert(row["bot_id"], "quality_drop", "high",
                 f"{row['scorer']} is {float(row['rate']):.0%} over 7 days (needs {t:.0%}).",
                 dedupe_key=f"quality:{row['bot_id']}:{row['scorer']}:{__import__('datetime').date.today()}")

# Guardrail spikes (MON-4, optional alert): blocked/refused share doubled vs prior week
for row in sql.query(f"""
    SELECT bot_id,
      avg(CASE WHEN ts >= current_timestamp() - INTERVAL 1 DAY AND outcome IN ('blocked','refused') THEN 1.0
               WHEN ts >= current_timestamp() - INTERVAL 1 DAY THEN 0.0 END) AS today,
      avg(CASE WHEN ts < current_timestamp() - INTERVAL 1 DAY AND outcome IN ('blocked','refused') THEN 1.0
               WHEN ts < current_timestamp() - INTERVAL 1 DAY THEN 0.0 END) AS baseline
    FROM {settings.fq('request_log')} WHERE ts >= current_timestamp() - INTERVAL 8 DAYS
      AND channel = 'live' AND NOT synthetic
    GROUP BY bot_id"""):
    today, base = row["today"], row["baseline"]
    if today is not None and base is not None and float(today) > max(2 * float(base), 0.10):
        cp.alert(row["bot_id"], "guardrail_spike", "medium",
                 f"{float(today):.0%} of requests blocked or refused today vs {float(base):.0%} baseline.",
                 dedupe_key=f"spike:{row['bot_id']}:{__import__('datetime').date.today()}", required=False)

# Feedback loop (EVL-7)
for f in sql.query(f"""SELECT f.request_id, f.bot_id, r.question FROM {settings.fq('feedback')} f
                       JOIN {settings.fq('request_log')} r USING (request_id)
                       WHERE f.rating = 'down' AND NOT coalesce(f.added_to_eval, false)"""):
    p = BotPaths(settings, f["bot_id"])
    sql.execute(f"""INSERT INTO {p.t('golden_set')} (eval_id, question, expected_answer, kind, difficulty,
                    question_type, origin, approved, active, updated_by, updated_at)
                    VALUES (:id, :q, '', 'feedback', 'hard', 'user_feedback', 'feedback', false, true,
                    'system:feedback', current_timestamp())""",
                {"id": str(uuid.uuid4()), "q": f["question"]})
    sql.execute(f"UPDATE {settings.fq('feedback')} SET added_to_eval = true WHERE request_id = :r",
                {"r": f["request_id"]})
