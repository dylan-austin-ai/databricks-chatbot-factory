"""Platform setup (re-runnable): control plane, views, grants, shared AI Search, platform alerts.

Grants (PRV-1, REL-10):
  * raw logs (request_log, guardrail_events, conversations, logs volume): Security + MLOps only
  * redacted views: support group
  * runtime volume: read for the agent service principal; logs volume: write for it
  * everything owned by the app service principal; no one else gets MODIFY
"""
from _bootstrap import ACTOR, args, context, vector_client

from factory.provisioning import ensure_shared_index, principal
from factory.sql import ident

a = args("catalog", "agent_principal")
spark, sql, settings, cp, w = context(a.catalog)
s = settings
sql.execute(f"CREATE CATALOG IF NOT EXISTS {ident(s.catalog)}")
cp.ensure()
cp.ensure_views()

security, admins, support = (s.get("access.security_group"), s.get("access.admin_group"),
                             s.get("access.support_group"))
app_sp = s.get("access.app_service_principal")
platform = ident(s.catalog, s.platform_schema)
if app_sp:
    sql.execute(f"ALTER SCHEMA {platform} OWNER TO {principal(app_sp)}")
for grp in filter(None, {security, admins, support, a.agent_principal}):
    sql.execute(f"GRANT USE CATALOG ON CATALOG {ident(s.catalog)} TO {principal(grp)}")
    sql.execute(f"GRANT USE SCHEMA ON SCHEMA {platform} TO {principal(grp)}")
for grp in filter(None, {security, admins}):
    for t in ("request_log", "guardrail_events", "conversations", "user_access", "releases",
              "release_chunks", "index_history", "snapshots", "audit_log", "eval_runs",
              "monitoring_rollup", "synthetic_health", "cost_daily", "alerts"):
        sql.execute(f"GRANT SELECT ON TABLE {platform}.{ident(t)} TO {principal(grp)}")
    sql.execute(f"GRANT READ VOLUME ON VOLUME {platform}.`logs` TO {principal(grp)}")
if support:
    for v in ("request_log_redacted", "guardrail_events_redacted", "v_bot_activity", "v_monitoring",
              "v_guardrails", "v_alerts_open", "v_releases", "v_eval_latest"):
        sql.execute(f"GRANT SELECT ON VIEW {platform}.{ident(v)} TO {principal(support)}")
if a.agent_principal:
    sql.execute(f"GRANT READ VOLUME ON VOLUME {platform}.`runtime` TO {principal(a.agent_principal)}")
    sql.execute(f"GRANT WRITE VOLUME ON VOLUME {platform}.`logs` TO {principal(a.agent_principal)}")
    sql.execute(f"GRANT SELECT ON TABLE {platform}.`user_access` TO {principal(a.agent_principal)}")

ensure_shared_index(vector_client(), settings)
cp.publish(None)  # settings.json for the agent

try:
    from factory.alerting import ensure_bot_alerts
    ensure_bot_alerts(w, s, None, s.get("warehouse_id"))  # platform alerts to MLOps
except Exception as e:  # noqa: BLE001
    print(f"Platform email alerts need manual setup: {e}")

cp.audit(ACTOR, None, "platform_setup", s.catalog, {})
print(f"Platform ready in catalog {s.catalog}")
