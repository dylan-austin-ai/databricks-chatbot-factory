"""Nightly maintenance (LCY-5, LCY-6, DOC-11, CAS-6, ADM-6).

* Drift detection: write access or objects in bot schemas the app didn't create.
* Idle bots: no requests in N days -> flag to owner.
* Expired platform pins -> remove pin.
* Soft-deleted bots past their retention window -> drop schema (audit kept).
* Rows older than the retention period (7 years) -> purge.
"""
from _bootstrap import args, context

a = args("catalog")
spark, sql, settings, cp, w = context(a.catalog)
app_sp = settings.get("access.app_service_principal")
cat = settings.catalog
bots = cp.list_bots()
schemas = [b["bot_id"] for b in bots]

if schemas and app_sp:
    in_list = ", ".join(f":s{i}" for i in range(len(schemas)))
    params = {f"s{i}": s for i, s in enumerate(schemas)}
    params["sp"] = app_sp
    for row in sql.query(
        f"""SELECT table_schema, table_name, grantee, privilege_type
            FROM `{cat}`.information_schema.table_privileges
            WHERE table_schema IN ({in_list}) AND grantee <> :sp
              AND privilege_type IN ('MODIFY', 'ALL PRIVILEGES')""", params):
        cp.alert(row["table_schema"], "drift", "high",
                 f"{row['grantee']} has {row['privilege_type']} on {row['table_name']} "
                 "(bot infrastructure must only be changed through the app).",
                 dedupe_key=f"drift:{row['table_schema']}:{row['table_name']}:{row['grantee']}")
    for row in sql.query(
        f"""SELECT table_schema, table_name, created_by FROM `{cat}`.information_schema.tables
            WHERE table_schema IN ({in_list}) AND created_by <> :sp""", params):
        cp.alert(row["table_schema"], "drift", "high",
                 f"{row['table_name']} was created outside the app by {row['created_by']}.",
                 dedupe_key=f"drift:{row['table_schema']}:{row['table_name']}:created")

idle_days = int(settings.get("idle_days_before_flag", 45))
for row in sql.query(f"""
    SELECT b.bot_id, b.owner_user, max(r.ts) AS last_ts FROM {settings.fq('bots')} b
    LEFT JOIN {settings.fq('request_log')} r ON r.bot_id = b.bot_id AND NOT r.synthetic
    WHERE b.state = 'live' AND b.deleted_at IS NULL GROUP BY b.bot_id, b.owner_user
    HAVING max(r.ts) IS NULL OR max(r.ts) < current_timestamp() - make_interval(0,0,0,{idle_days},0,0,0)"""):
    cp.alert(row["bot_id"], "idle", "low",
             f"No questions in {idle_days}+ days. {row['owner_user']}: consider archiving it.",
             dedupe_key=f"idle:{row['bot_id']}:{__import__('datetime').date.today():%Y-%m}", required=False)

sql.execute(f"""UPDATE {settings.fq('bots')} SET platform_pin = NULL, pin_expires_at = NULL
               WHERE pin_expires_at < current_timestamp()""")

keep_days = int(settings.get("soft_delete_retention_days", 90))
for b in sql.query(f"""SELECT bot_id FROM {settings.fq('bots')} WHERE deleted_at IS NOT NULL
                      AND deleted_at < current_timestamp() - make_interval(0,0,0,{keep_days},0,0,0)"""):
    sql.execute(f"DROP SCHEMA IF EXISTS `{cat}`.`{b['bot_id']}` CASCADE")
    sql.execute(f"DELETE FROM {settings.fq('shared_chunks')} WHERE bot_id = :b", {"b": b["bot_id"]})
    cp.audit("system:maintenance", b["bot_id"], "schema_purged", "", {"after_days": keep_days})

years = int(settings.get("retention_years", 7))
for table in ("request_log", "guardrail_events", "conversations", "judge_results", "feedback",
              "synthetic_health"):
    sql.execute(f"DELETE FROM {settings.fq(table)} WHERE ts < current_timestamp() - INTERVAL {years} YEARS")
