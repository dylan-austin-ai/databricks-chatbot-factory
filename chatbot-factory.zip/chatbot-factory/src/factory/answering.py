"""Pure answer-path helpers shared by the agent and unit tests (CNV-1, RET-2, DCL-1, ANS-1/2)."""
from __future__ import annotations


def search_filters(bot_id: str, channel: str, now: int) -> dict:
    """Channel + effective/expiry window enforced inside the AI Search request (DCL-1, REL-1)."""
    return {"bot_id": bot_id, "in_live" if channel == "live" else "in_candidate": True,
            "effective_ts <=": now, "expires_ts >": now}


def bounded_history(msgs: list[dict], mode: str, max_turns: int, max_chars: int) -> list[dict]:
    """CNV-1: off = latest question only; otherwise bounded by turns and characters."""
    if mode == "off" or not msgs:
        return msgs[-1:]
    hist = msgs[-2 * max_turns:]
    while len(hist) > 1 and sum(len(m["content"]) for m in hist) > max_chars:
        hist = hist[1:]
    return hist


def search_query(history: list[dict], mode: str) -> str:
    """RET-2 default (no LLM): follow-ups search with the previous + current question."""
    user_turns = [m["content"] for m in history if m["role"] == "user"]
    if not user_turns:
        return ""
    if mode != "off" and len(user_turns) > 1:
        return f"{user_turns[-2]} {user_turns[-1]}"
    return user_turns[-1]


def render(answer: str, citations: list[dict], conflicts: list[dict]) -> str:
    lines = [answer, "", "Sources:"]
    for c in citations:
        where = f"page(s) {c['pages']}" + (f", section \"{c['section']}\"" if c.get("section") else "")
        lines.append(f"[{c['n']}] {c['doc_name']} (v{c.get('doc_version')}), {where}: “{c['excerpt']}”")
    for cf in conflicts:
        refs = " and ".join(f"[{n}]" for n in cf.get("sources", []))
        lines.append(f"⚠️ Sources disagree ({refs}): {cf.get('note', '')}")
    return "\n".join(lines)
