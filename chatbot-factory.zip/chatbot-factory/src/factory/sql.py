"""One SQL interface for jobs (Spark) and the app/agent (SQL warehouse).

All user-supplied values go through named parameters, never string formatting.
Identifiers (catalog/schema/table names) are validated and backtick-quoted.
"""
from __future__ import annotations

import re
import time
from typing import Any, Protocol

_IDENT = re.compile(r"^[A-Za-z0-9_]+$")


def ident(*parts: str) -> str:
    """Quote a dotted identifier after validating each part."""
    out = []
    for p in parts:
        if not _IDENT.match(p or ""):
            raise ValueError(f"Unsafe identifier: {p!r}")
        out.append(f"`{p}`")
    return ".".join(out)


class SqlRunner(Protocol):
    def execute(self, statement: str, params: dict[str, Any] | None = None) -> None: ...
    def query(self, statement: str, params: dict[str, Any] | None = None) -> list[dict]: ...


class SparkRunner:
    """Used inside Databricks jobs."""

    def __init__(self, spark):
        self.spark = spark

    def execute(self, statement, params=None):
        self.spark.sql(statement, args=params or {})

    def query(self, statement, params=None):
        return [r.asDict(recursive=True) for r in self.spark.sql(statement, args=params or {}).collect()]


class WarehouseRunner:
    """Used by the app and the agent, via the Statement Execution API."""

    def __init__(self, workspace_client, warehouse_id: str, timeout_s: int = 120):
        self.w = workspace_client
        self.warehouse_id = warehouse_id
        self.timeout_s = timeout_s

    def _run(self, statement, params):
        from databricks.sdk.service.sql import StatementParameterListItem, StatementState

        p = [
            StatementParameterListItem(name=k, value=None if v is None else str(v))
            for k, v in (params or {}).items()
        ]
        resp = self.w.statement_execution.execute_statement(
            warehouse_id=self.warehouse_id, statement=statement, parameters=p,
            wait_timeout="30s",
        )
        deadline = time.time() + self.timeout_s
        while resp.status.state in (StatementState.PENDING, StatementState.RUNNING):
            if time.time() > deadline:
                raise TimeoutError("SQL statement timed out")
            time.sleep(1)
            resp = self.w.statement_execution.get_statement(resp.statement_id)
        if resp.status.state != StatementState.SUCCEEDED:
            err = resp.status.error
            raise PermissionError(err.message) if err and "PERMISSION" in (err.message or "").upper() \
                else RuntimeError(err.message if err else str(resp.status.state))
        return resp

    def execute(self, statement, params=None):
        self._run(statement, params)

    def query(self, statement, params=None):
        resp = self._run(statement, params)
        if not resp.result or not resp.result.data_array:
            return []
        cols = [c.name for c in resp.manifest.schema.columns]
        return [dict(zip(cols, row)) for row in resp.result.data_array]
