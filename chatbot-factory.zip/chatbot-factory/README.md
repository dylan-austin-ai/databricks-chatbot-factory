# Chatbot Factory (v2)

A Databricks App that lets non-technical people build governed RAG chatbots from their own
documents through a guided wizard. Everything is Databricks-native, runs on shared
infrastructure, and is governed by Unity Catalog.

```
Owner ─► App (wizard · documents · test questions · launch · chat · admin)
           │ Go
           ▼
   provision → ingest jobs (serverless)
     ai_parse_document → ai_prep_search → chunked → QA, injection scan, PII block
     golden set (easy + hard extraction questions) → strategy comparison → eval gate
           │ stage = candidate release (in_candidate rows in the index)
           ▼
   AI Search: one endpoint · shared index (bot_id filter) · dedicated index for Confidential
           ▲  filters: bot_id · channel · effective_ts ≤ now < expires_ts · rerank
User / middleware ─► ONE agent endpoint (config from runtime volume, no warehouse)
           │ identity (OBO, or trusted middleware asserting end_user) · UC access probe
           │ Haiku via guardrailed AI Gateway endpoint · JSON answer · excerpt verification
           ▼
   JSON logs → logs volume → monitor job (15 min) → request_log, guardrail_events, rollups,
   alerts (email via SQL alerts), budgets, expiry notices · hourly canary · app health probe
```

**Releases.** Bots have a *test* (candidate) and *live* version in prod; no dev copy per bot.
Changes stage a candidate, the combined gate runs (Hit@1 ≥ .80, Hit@3 ≥ .90, Hit@5 ≥ .95,
MRR ≥ .85, judges ≥ 90%, zero deterministic failures; unsafe flags go to the Reviewer), the
Reviewer approves, the promote job flips rows to live, syncs, smoke-tests and auto-rolls back on
failure. `releases`, `release_chunks` and `index_history` reconstruct the index for any day
(`Releases.index_as_of_sql`). Platform code moves dev → prod as the exact git commit.

## Layout

| Path | What it is |
|---|---|
| `src/factory/` | Library: config, ingestion SQL, releases, provisioning, guardrails, identity, evals, strategies, monitoring, alerting |
| `src/factory/platform_defaults.yml` | Defaults; MLOps edits them on the Admin page (stored in `platform_settings`, published to the runtime volume) |
| `agent/agent.py`, `agent/deploy.py` | The single shared agent and its gated deploy |
| `app/` | Streamlit app styled to the Claude Design screens (`app/ui.py`, `.streamlit/config.toml`) |
| `docs/design/`, `docs/UI_REQUIREMENTS.md` | The design canvas files and the screen-by-screen UI spec |
| `jobs/` | setup, provision, ingest, compare_strategies, run_evals, promote, monitor, prod_judging, reindex, git_sync, maintenance |
| `sql/` | Control-plane DDL, per-bot DDL, dashboard and redacted views |
| `resources/`, `databricks.yml` | Asset Bundle (dev and prod) |
| `tests/` | 63 unit tests for the pure logic |

## Prerequisites

1. AWS us-east workspace with Unity Catalog, serverless, Model Serving, AI Search, Apps, and
   `ai_parse_document` / `ai_prep_search` (Beta: enable on Previews; DBR 18.2+).
2. Serverless SQL warehouse.
3. AI Gateway endpoint `chatbot-haiku-guarded` over Claude Haiku with PII, jailbreak/prompt
   injection, unsafe content and rate-limit guardrails. A Sonnet endpoint for judges.
4. App service principal with `USE CATALOG`, `CREATE SCHEMA`, `MANAGE` on the catalog.
5. **Agent service principal** (writes logs, reads runtime config): secret scope
   `chatbot-factory` with `agent-sp-client-id` and `agent-sp-client-secret`. Pass its
   application ID as `--var agent_principal=...`.
6. **Identity keys (Security-only)**: secret scope `chatbot-factory-identity` with
   `pseudonym-hmac-key` (random bytes) and `identity-fernet-key`
   (`Fernet.generate_key()`). Only the Security group may read this scope.
7. Groups: `mlops` (admin), `security` (raw logs, break-glass), `support` (redacted views).
8. Private git repos: `git-token` in scope `chatbot-factory`.

## Deploy

```bash
databricks bundle deploy -t dev --var warehouse_id=<id> --var agent_principal=<app-id>
databricks bundle run setup_platform -t dev
databricks bundle run deploy_agent -t dev
databricks bundle run chatbot_factory -t dev
```

Prod: run `run_evals bot_id=all` in dev on the commit, then deploy the same commit with
`-t prod`. `deploy_agent` refuses unless dev evals passed for that platform version and commit.
Existing prod resources can be adopted with `databricks bundle deployment bind`.

## Verify against a live workspace first

The code is unit-tested offline only. Check: `w.alerts_v2` request shape (`factory/alerting.py`);
the `DatabricksReranker` import path and `similarity_search(reranker=...)`; AI Search filter
operators (`"effective_ts <="`); `ai_prep_search` output fields; `agents.deploy` OBO scopes and
`custom_outputs` round-trip; agent SP write grant on the logs volume; COPY INTO into
`request_events` / `health_events`.

**Cost note:** the agent never touches the SQL warehouse on the hot path except UC access
probes (cached 15 min per user). The 15-minute monitor job and SQL email alerts do use the
warehouse; widen the schedule if warehouse cost matters more than alert latency.

## Not built (day 2 / maybes)

Document-level access enforcement (data model ships: `user_access`, scopes on chunks),
Excel/CSV path, SharePoint, instructed retrieval (ARC-7).
