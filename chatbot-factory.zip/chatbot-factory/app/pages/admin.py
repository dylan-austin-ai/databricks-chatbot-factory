"""MLOps-only admin (ADM-2..8, ARC-8, MON-6, CAS-6/7, IDN-1/3).

Platform settings are edited as YAML: every value in platform_defaults.yml (thresholds,
models, pricing, monitoring, trusted callers, groups, retention) in one place.
"""
import io
from datetime import datetime, timedelta

import pandas as pd
import streamlit as st
import yaml

from common import cp, current_user, is_admin, run_job, settings, sql

if not is_admin():
    st.error("This page is for MLOps admins only.")
    st.stop()

st.title("Admin settings")
s, user, control = settings(), current_user(), cp()
t_platform, t_bots, t_users, t_alerts, t_audit = st.tabs(
    ["Platform", "Chatbots", "User access", "Alerts", "Audit log"])

with t_platform:
    current = s.as_dict()
    current.pop("catalog", None)
    text = st.text_area("Platform settings (YAML)", yaml.safe_dump(current, sort_keys=False), height=600)
    if st.button("Save settings", type="primary"):
        try:
            new = yaml.safe_load(text)
            endpoints = new["models"]["answer_endpoints"]
            if new["models"]["default_answer_model"] not in endpoints:
                raise ValueError("default_answer_model must be one of models.answer_endpoints (ARC-8).")
            changed = [k for k in new if new[k] != current.get(k)]
            for k in changed:
                control.set_setting(k, new[k], user)
            st.cache_data.clear()
            if changed:
                run_job("evals", bot_id="all", trigger="settings_changed")  # EVL-6
            st.success(f"Saved {len(changed)} section(s): {', '.join(changed) or 'none'}. "
                       "The agent picks them up within a minute; all chatbots are being re-checked.")
        except Exception as e:  # noqa: BLE001
            st.error(f"Not saved: {e}")
    st.subheader("Re-index after a parser or chunker change (CAS-7)")
    c1, c2 = st.columns(2)
    parser = c1.selectbox("Affected parser", ["all", "ai_parse_document", "text_reader"])
    exts = c2.text_input("Only these file types (optional, e.g. md,txt)")
    if st.button("Re-index affected documents now"):
        run_job("reindex", parser=parser, extensions=exts)
        st.success("Re-index started.")

with t_bots:
    models = list(s.get("models.answer_endpoints"))
    for b in control.list_bots():
        cfg = control.get_config(b["bot_id"])
        with st.expander(f"{b['display_name']} · {b['state']}"):
            k = b["bot_id"]
            crit = st.checkbox("Critical (100% production judging)", cfg.critical, key=f"c_{k}")
            model = st.selectbox("Answer model", models, key=f"m_{k}",
                                 index=models.index(cfg.answer_model) if cfg.answer_model in models else 0)
            vis = st.checkbox("Visual extraction check", cfg.visual_judge, key=f"v_{k}")
            rules = s.get("guardrails.platform_rules", {})
            off = st.multiselect("Platform rules turned OFF for this chatbot", list(rules),
                                 [r for r in cfg.disabled_rules if r in rules], key=f"o_{k}",
                                 format_func=lambda r: rules[r])
            rewrite = st.checkbox("Rewrite follow-up questions with the LLM (RET-2)", cfg.query_rewrite,
                                  key=f"r_{k}")
            pin = st.text_input("Pin to platform version (temporary)", b.get("platform_pin") or "", key=f"p_{k}")
            days = st.number_input("Pin expires in (days)", 1, 30, 7, key=f"d_{k}")
            if st.button("Save", key=f"s_{k}"):
                cfg.critical, cfg.answer_model, cfg.visual_judge, cfg.query_rewrite = crit, model, vis, rewrite
                cfg.disabled_rules = off
                control.save_config(cfg, user, "admin update")
                if pin:
                    sql().execute(f"UPDATE {s.fq('bots')} SET platform_pin = :p, pin_expires_at = "
                                  "CAST(:e AS TIMESTAMP) WHERE bot_id = :b",
                                  {"p": pin, "e": (datetime.utcnow() + timedelta(days=int(days))).isoformat(),
                                   "b": k})
                    control.audit(user, k, "platform_pinned", pin, {"days": int(days)})
                run_job("ingest", bot_id=k, publish_only="true")  # stage as a candidate (REL-5)
                st.success("Saved to the test version; it goes live after Reviewer approval.")

with t_users:  # IDN-3
    st.write("Upload a CSV with columns: user_id, country, state, business_function, security_scopes "
             "(semicolon-separated), active, valid_from, valid_to. Rows replace existing ones per user.")
    f = st.file_uploader("user_access.csv", type=["csv"])
    if f and st.button("Load"):
        df = pd.read_csv(io.BytesIO(f.getvalue()), dtype=str).fillna("")
        for r in df.to_dict("records"):
            sql().execute(f"DELETE FROM {s.fq('user_access')} WHERE lower(user_id) = lower(:u)", {"u": r["user_id"]})
            sql().execute(
                f"""INSERT INTO {s.fq('user_access')} VALUES (lower(:u), :c, :st, :fn, split(:sc, ';'),
                    CAST(:a AS BOOLEAN), CAST(nullif(:vf, '') AS DATE), CAST(nullif(:vt, '') AS DATE),
                    'csv', current_timestamp())""",
                {"u": r["user_id"], "c": r.get("country"), "st": r.get("state"), "fn": r.get("business_function"),
                 "sc": r.get("security_scopes", ""), "a": r.get("active", "true") or "true",
                 "vf": r.get("valid_from", ""), "vt": r.get("valid_to", "")})
        control.audit(user, None, "user_access_loaded", f.name, {"rows": len(df)})
        st.success(f"Loaded {len(df)} user(s).")

with t_alerts:
    alerts = sql().query(f"SELECT * FROM {s.fq('v_alerts_open')} ORDER BY ts DESC LIMIT 200")
    if not alerts:
        st.success("No open alerts.")
    for a in alerts:
        c1, c2 = st.columns([6, 1])
        c1.write(f"**{a['severity']}** · {a['bot_id'] or 'platform'} · {a['kind']} · {a['ts']}  \n{a['message']}")
        if c2.button("Resolve", key=a["alert_id"]):
            sql().execute(f"UPDATE {s.fq('alerts')} SET resolved = true WHERE alert_id = :a", {"a": a["alert_id"]})
            control.audit(user, a["bot_id"], "alert_resolved", a["alert_id"])
            st.rerun()

with t_audit:
    bot_filter = st.text_input("Filter by chatbot (technical name)")
    q = f"SELECT ts, actor, bot_id, action, target, detail_json FROM {s.fq('audit_log')}"
    params = {}
    if bot_filter:
        q, params = q + " WHERE bot_id = :b", {"b": bot_filter}
    st.dataframe(sql().query(q + " ORDER BY ts DESC LIMIT 500", params), use_container_width=True)
