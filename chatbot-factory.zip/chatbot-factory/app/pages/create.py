"""Creator wizard in the design's 6 steps (WIZ-1..10, CNV-1, IDN-2, DCL-1, CST-8, REL-1, GRD-16).

After Go, provisioning, parsing, checks, test questions, strategy comparison and the first
evaluation run in the background; the result lands as a test version the owner can try.
"""
import datetime as dt
from html import escape as esc

import streamlit as st

from common import app_client, cp, current_user, docs, run_job, settings, sql
from factory.config import MAX_TESTERS, BotConfig
from factory.guardrails import platform_rules
from factory.lifecycle import State
from factory.naming import NamingError, validate
from factory.provisioning import Provisioner
from ui import html, steps

STEPS = ["Name and purpose", "People", "Who can use it", "Documents", "Answers and safety", "Budget and review"]
BUILT_IN = ("harmful content filter, personal data masking, jailbreak blocking, removal of hidden "
            "instructions in documents, exact source quotes, \"I don't know\" when the documents don't say, "
            "conflict disclosure, no invented links")
FREQ_EXPIRY_DAYS = {"weekly": 30, "monthly": 90, "rarely": 365}

s = settings()
w = st.session_state.setdefault("wizard", {"step": 0})
st.caption("New chatbot" + (f" · `{w['bot_id']}`" if w.get("bot_id") else ""))
st.title(STEPS[w["step"]])
steps(w["step"], STEPS)


def nav(problems: list[str]) -> None:
    for p in problems:
        st.error(p)
    c1, _, c2 = st.columns([1, 3, 1])
    if w["step"] > 0 and c1.button("Back", use_container_width=True):
        w["step"] -= 1
        st.rerun()
    if w["step"] < len(STEPS) - 1 and c2.button("Next", type="primary", use_container_width=True,
                                                disabled=bool(problems)):
        w["step"] += 1
        st.rerun()


def radio(label: str, options: dict[str, str], key: str, default: str, **kw) -> None:
    labels = list(options)
    current = next((k for k, v in options.items() if v == w.get(key, default)), labels[0])
    w[key] = options[st.radio(label, labels, index=labels.index(current), **kw)]


step, problems = STEPS[w["step"]], []

if step == "Name and purpose":
    w["display_name"] = st.text_input("What should we call your chatbot?", w.get("display_name", ""),
                                      placeholder="Claims Chatbot")
    w["purpose"] = st.text_area("In one sentence, what will it help people with?", w.get("purpose", ""),
                                placeholder="Answers adjusters' questions about claims procedures.")
    funcs = s.get("wizard.business_functions")
    w["business_function"] = st.selectbox("Which business function is it for?", funcs,
                                          index=funcs.index(w["business_function"])
                                          if w.get("business_function") in funcs else 0)
    try:
        w["bot_id"] = validate(w["display_name"], cp().existing_bot_ids()) if w["display_name"] else ""
        if w["bot_id"]:
            st.caption(f"Technical name: `{w['bot_id']}` (can't be changed later)")
    except NamingError as e:
        problems.append(str(e))
    if not (w["display_name"] and w["purpose"]):
        problems.append("Add a name and a purpose.")

elif step == "People":
    c1, c2 = st.columns(2)
    w["owner_user"] = c1.text_input("Owner (person)", w.get("owner_user", current_user()))
    w["owner_group"] = c2.text_input("Owner group", w.get("owner_group", ""))
    w["reviewer"] = st.text_input("Who approves new versions before they go live? (person or group)",
                                  w.get("reviewer", ""))
    txt = st.text_area(f"Testers who can try the test version (up to {MAX_TESTERS}, one email per line)",
                       "\n".join(w.get("testers", [])))
    w["testers"] = [t.strip() for t in txt.splitlines() if t.strip()]
    st.caption(f"{len(w['testers'])} of {MAX_TESTERS}")
    if not (w["owner_user"] and w["owner_group"] and w["reviewer"]):
        problems.append("Add an owner, an owner group and a reviewer.")
    if len(w["testers"]) > MAX_TESTERS:
        problems.append(f"You can invite up to {MAX_TESTERS} testers.")

elif step == "Who can use it":
    radio("Who will use this chatbot?", {"People in my organization": "restricted",
                                         "Through another app": "middleware"}, "access_mode", "restricted")
    if w["access_mode"] == "restricted":
        txt = st.text_area("Which groups or people? (one per line)", "\n".join(w.get("allowed_principals", [])))
        w["allowed_principals"] = [x.strip() for x in txt.splitlines() if x.strip()]
        if not w["allowed_principals"]:
            problems.append("Add at least one group or person.")
    else:
        w["allowed_principals"] = []
        st.info("Chatbots used through another app can only use Public documents for now.")
    radio("How will people reach it?", {"Chat page": "chat", "API": "api", "Both": "both"}, "channel", "chat",
          horizontal=True)

elif step == "Documents":
    radio("How sensitive are these documents?", {"Public": "public", "Internal": "internal",
                                                 "Confidential": "confidential"}, "sensitivity", "internal",
          horizontal=True)
    if w.get("access_mode") == "middleware" and w["sensitivity"] != "public":
        problems.append("Chatbots used through another app can only use Public documents for now.")
    sources = {"Upload files": "upload", "Git repository": "git"}
    if s.get("ingestion.enable_sharepoint"):
        sources["SharePoint"] = "sharepoint"
    radio("Where do the documents live?", sources, "source_type", "upload", horizontal=True)
    if w["source_type"] == "upload":
        exts = s.get("ingestion.parse_extensions") + s.get("ingestion.text_extensions") + (
            s.get("ingestion.tabular_extensions") if s.get("ingestion.enable_tabular") else [])
        files = st.file_uploader("Drag and drop documents (up to 100 MB / 500 pages each)",
                                 accept_multiple_files=True, type=exts)
        if files:
            w["files"] = {f.name: f.getvalue() for f in files}
        st.caption(f"{len(w.get('files', {}))} file(s) ready")
    else:
        w["source_uri"] = st.text_input("Repository or SharePoint link", w.get("source_uri", ""))
    radio("How often do they change?", {"Rarely": "rarely", "Monthly": "monthly", "Weekly": "weekly"},
          "change_frequency", "rarely", horizontal=True)
    radio("Do they expire?", {"Valid until replaced by a newer version": "no",
                              "They expire on a date": "yes"}, "expires", "no")
    w["no_expiry"] = w["expires"] == "no"
    if not w["no_expiry"]:
        w["expires_at"] = st.date_input("Expiry date", w.get("expires_at") or dt.date.today()
                                        + dt.timedelta(days=FREQ_EXPIRY_DAYS[w["change_frequency"]]))
        st.caption("You'll get an email a month before. You can set dates per document later.")
    radio("Test questions", {"Write them for me": "generate", "I'll write my own": "manual",
                             "Later": "skip"}, "golden_set_mode", "generate", horizontal=True,
          help=f"{s.get('quality.min_golden_questions', 50)} approved test questions are needed to go live.")
    if not (w.get("files") or w.get("source_uri")):
        problems.append("Add documents (or a link) to continue.")

elif step == "Answers and safety":
    radio("How should answers sound?", {"Short and direct": "short", "Detailed": "detailed"},
          "answer_style", "short", horizontal=True)
    rules = "".join(f"<li>{esc(r)}</li>" for r in platform_rules(s.get("guardrails.platform_rules", {}), []))
    html(f'<div class="cf-locked"><b>Rules for every chatbot</b> <span class="cf-muted">· set by MLOps, '
         f'always on</span><ul>{rules}</ul><span class="cf-muted">Also built in: {BUILT_IN}.</span></div>')
    extra = st.text_input("Add your own topics to refuse (optional, comma separated)",
                          ", ".join(w.get("refuse_topics", [])), placeholder="e.g. Reinsurance treaties")
    w["refuse_topics"] = [x.strip() for x in extra.split(",") if x.strip()]
    forced = w.get("access_mode") == "middleware"
    w["limit_quotes"] = st.toggle("Keep quoted text short" + (" (required for chatbots used through another app)"
                                  if forced else ""), value=w.get("limit_quotes", False) or forced, disabled=forced)
    radio("Who appears in the logs?", {"Named: logs show who asked": "named",
                                       "Pseudonymous: only Security can look up the person": "pseudonymous"},
          "identity_mode", "named")
    memory = {"No": "off", "This conversation only": "session"}
    if w["identity_mode"] == "named":
        memory["Saved: people can come back to past chats"] = "saved"
    elif w.get("history_mode") == "saved":
        w["history_mode"] = "session"
    radio("Should it remember the conversation?", memory, "history_mode", "session", horizontal=True)
    if w["identity_mode"] == "pseudonymous":
        st.caption("Saved conversations aren't available when people are pseudonymous.")

else:  # Budget and review
    w["budget_usd"] = st.number_input("Monthly budget ($)", 50, 100000, int(w.get("budget_usd", 1000)), step=50,
                                      help="A ceiling, not a forecast. Most chatbots use far less.")
    radio("When the budget is reached", {"Keep running and alert me": "continue",
                                         "Pause the chatbot until the 1st": "pause"}, "budget_action", "continue")
    w["traffic_alerts"] = st.toggle("Alert me about unusual traffic", value=w.get("traffic_alerts", True))
    st.caption("Always on: alerts for outages, slow answers, errors, budget and expiring documents.")
    cfg = BotConfig(
        bot_id=w.get("bot_id", ""), display_name=w.get("display_name", ""), purpose=w.get("purpose", ""),
        owner_user=w.get("owner_user", ""), owner_group=w.get("owner_group", ""),
        business_function=w.get("business_function", ""), access_mode=w.get("access_mode", "restricted"),
        allowed_principals=w.get("allowed_principals", []),
        channels=["chat", "api"] if w.get("channel") == "both" else [w.get("channel", "chat")],
        refuse_topics=w.get("refuse_topics", []), answer_style=w.get("answer_style", "short"),
        history_mode=w.get("history_mode", "session"), identity_mode=w.get("identity_mode", "named"),
        sensitivity=w.get("sensitivity", "internal"), source_type=w.get("source_type", "upload"),
        source_uri=w.get("source_uri", ""), change_frequency=w.get("change_frequency", "rarely"),
        golden_set_mode=w.get("golden_set_mode", "generate"), reviewer=w.get("reviewer", ""),
        testers=w.get("testers", []), team=w.get("owner_group", ""),
        answer_model=s.get("models.default_answer_model"), limit_quotes=w.get("limit_quotes", False),
        budget_usd=float(w.get("budget_usd", 1000)), budget_action=w.get("budget_action", "continue"),
        alert_prefs={"traffic": bool(w.get("traffic_alerts", True))},
    )
    with st.container(border=True):
        st.markdown("**Review**")
        for label, i, value in [
            ("Name", 0, cfg.display_name), ("Purpose", 0, cfg.purpose),
            ("Owner", 1, f"{cfg.owner_user} ({cfg.owner_group})"), ("Reviewer", 1, cfg.reviewer),
            ("Who can use it", 2, "Through another app" if cfg.access_mode == "middleware"
             else ", ".join(cfg.allowed_principals)),
            ("Documents", 3, f"{len(w.get('files', {}))} file(s), {cfg.sensitivity}"),
            ("Extra topics to refuse", 4, ", ".join(cfg.refuse_topics) or "None"),
        ]:
            c1, c2, c3 = st.columns([2, 5, 1])
            c1.caption(label)
            c2.write(value or "—")
            if c3.button("Edit", key=f"edit_{label}"):
                w["step"] = i
                st.rerun()
    problems = cfg.validate()
    for p in problems:
        st.error(p)
    c1, _, c2 = st.columns([1, 3, 1])
    if c1.button("Back", use_container_width=True):
        w["step"] -= 1
        st.rerun()
    if c2.button("Go", type="primary", use_container_width=True, disabled=bool(problems)):
        user = current_user()
        with st.status("Creating workspace…", expanded=True) as status:
            control = cp()
            control.save_config(cfg, user, "created", state=State.DRAFT.value)
            Provisioner(sql(), s, control, app_client()).run(
                cfg, user, progress=st.write, only=["create_objects", "tag_objects", "grant_access", "write_config"])
            for name, data in w.get("files", {}).items():
                res = docs().register(cfg.bot_id, name, data, user, change_frequency=cfg.change_frequency,
                                      no_expiry=w["no_expiry"],
                                      expires_at=None if w["no_expiry"] else str(w.get("expires_at")),
                                      doc_owner=cfg.owner_user)
                if not res.ok:
                    st.warning(f"**{name}** wasn't added: {' '.join(res.reasons)}")
            st.write("Reading documents, checking quality, writing test questions and choosing the best "
                     "search method. This continues in the background.")
            run_job("provision", bot_id=cfg.bot_id, actor=user)
            status.update(label="Your chatbot is being built", state="complete")
        st.session_state["bot_id"] = cfg.bot_id
        st.session_state.pop("wizard", None)
        st.page_link("pages/documents.py", label="Next: check your documents", icon=":material/description:")
    st.stop()

nav(problems)
