"""Shared app plumbing: identity, services, permissions, job triggers."""
from __future__ import annotations

import os
import sys
from functools import lru_cache
from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from factory.config import BotConfig, PlatformSettings  # noqa: E402
from factory.controlplane import ControlPlane  # noqa: E402
from factory.documents import Documents  # noqa: E402
from factory.sql import WarehouseRunner  # noqa: E402

CATALOG = os.environ.get("FACTORY_CATALOG", "chatbots")
WAREHOUSE_ID = os.environ.get("FACTORY_WAREHOUSE_ID", "")
JOB_IDS = {
    "provision": os.environ.get("PROVISION_JOB_ID"),
    "ingest": os.environ.get("INGEST_JOB_ID"),
    "evals": os.environ.get("EVALS_JOB_ID"),
    "reindex": os.environ.get("REINDEX_JOB_ID"),
    "promote": os.environ.get("PROMOTE_JOB_ID"),
}
APP_VERSION = os.environ.get("FACTORY_APP_VERSION", "")

BADGE = {"green": "Good", "yellow": "Check it", "red": "Problem", "n/a": "Text file", None: "Reading…"}
STATE_LABEL = {
    "draft": "Draft", "provisioning": "Setting up", "provision_failed": "Setup failed",
    "testing": "Testing", "pending_approval": "Waiting for approval", "live": "Live",
    "paused": "Paused", "budget_paused": "Paused (budget reached)", "archived": "Archived",
    "deleted": "Deleted",
}
OUTCOME_LABEL = {  # UI-004: users can tell these apart
    "answered": None, "no_source": "Not covered by my documents",
    "refused": "Outside what I can help with", "blocked": "Blocked by a safety rule",
    "denied": "No access", "unverified": "Couldn't verify, showing sources",
    "unavailable": "Not available right now", "error": "Something went wrong",
}
METRIC_LABEL = {  # plain-English names for the go-live gate (EVG-1)
    "hit_at_1": "Right document first", "hit_at_3": "In the top 3", "hit_at_5": "In the top 5",
    "mrr": "Overall ranking", "correctness": "Correct", "groundedness": "Sticks to sources",
    "relevance": "Relevant", "citation_accuracy": "Citations accurate",
    "refusal_accuracy": "Refuses correctly", "safety": "Safe",
}
RETRIEVAL_METRICS = ["hit_at_1", "hit_at_3", "hit_at_5", "mrr"]


@lru_cache(maxsize=1)
def app_client():
    from databricks.sdk import WorkspaceClient
    return WorkspaceClient()  # the app's service principal


def user_client():
    """Client acting as the signed-in user (Databricks Apps user authorization)."""
    from databricks.sdk import WorkspaceClient
    token = st.context.headers.get("X-Forwarded-Access-Token")
    if not token:
        return app_client()
    return WorkspaceClient(host=app_client().config.host, token=token, auth_type="pat")


def current_user() -> str:
    return st.context.headers.get("X-Forwarded-Email") or os.environ.get("FACTORY_DEV_USER", "dev@local")


@st.cache_resource
def _sql():
    return WarehouseRunner(app_client(), WAREHOUSE_ID)


@st.cache_data(ttl=60)
def _overrides() -> dict:
    base = PlatformSettings.load({"catalog": CATALOG})
    try:
        o = ControlPlane(_sql(), base).load_overrides()
    except Exception:  # noqa: BLE001
        o = {}
    o["catalog"] = CATALOG
    return o


def settings() -> PlatformSettings:
    return PlatformSettings.load(_overrides())


def cp() -> ControlPlane:
    """Control plane; republishes the agent's runtime files on every change."""
    return ControlPlane(_sql(), settings(), app_client())


def sql() -> WarehouseRunner:
    return _sql()


def docs() -> Documents:
    return Documents(_sql(), settings(), cp(), app_client())


@st.cache_data(ttl=300)
def user_groups(email: str) -> set[str]:
    try:
        users = list(app_client().users.list(filter=f'userName eq "{email}"', attributes="groups"))
        return {g.display for u in users for g in (u.groups or []) if g.display}
    except Exception:  # noqa: BLE001
        return set()


def is_admin() -> bool:
    return settings().get("access.admin_group") in user_groups(current_user())


def is_tester(bot: dict) -> bool:
    import json as _json
    cfg = _json.loads(bot.get("config_json") or "{}")
    return current_user().lower() in {t.lower() for t in cfg.get("testers", [])}


def can_manage(bot: dict) -> bool:
    """Owner person, owner group, reviewer, or MLOps."""
    u = current_user()
    return (is_admin() or u in (bot.get("owner_user"), bot.get("reviewer"))
            or bot.get("owner_group") in user_groups(u))


def my_bots() -> list[dict]:
    return [b for b in cp().list_bots() if can_manage(b)]


def pick_bot(label: str = "Chatbot") -> tuple[dict, BotConfig] | tuple[None, None]:
    bots = my_bots()
    if not bots:
        st.info("You don't have any chatbots yet. Create one from **Create a chatbot**.")
        return None, None
    ids = [b["bot_id"] for b in bots]
    default = ids.index(st.session_state["bot_id"]) if st.session_state.get("bot_id") in ids else 0
    choice = st.sidebar.selectbox("Current chatbot", ids, index=default,
                          format_func=lambda i: next(b["display_name"] for b in bots if b["bot_id"] == i))
    st.session_state["bot_id"] = choice
    bot = next(b for b in bots if b["bot_id"] == choice)
    return bot, cp().get_config(choice)


def run_job(kind: str, **params) -> int | None:
    job_id = JOB_IDS.get(kind)
    if not job_id:
        st.error(f"The {kind} job isn't configured. Contact MLOps.")
        return None
    params.setdefault("catalog", CATALOG)
    run = app_client().jobs.run_now(job_id=int(job_id),
                                    job_parameters={k: str(v) for k, v in params.items()})
    return run.run_id


@st.cache_resource
def start_probe() -> bool:
    """Cheap synthetic probe from the always-on app (OBS-1): no LLM calls."""
    from probe import start
    start(app_client(), settings())
    return True
