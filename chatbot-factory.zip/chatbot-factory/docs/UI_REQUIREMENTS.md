# Chatbot Factory: UI requirements

Paste this into Claude Design. It describes every screen, what's on it, and what each action does.

## Product

An internal web app where non-technical employees build their own document chatbots in
minutes. Owners name the bot, answer a few questions, upload documents, check that the
documents were read correctly, approve test questions, and send the bot for approval. A
Reviewer approves it and it goes live. MLOps admins manage platform settings.

**Users:** Owner (creates and runs a bot), Reviewer (approves releases), Tester (up to 10 per
bot, tries the test version), End user (chats), Admin (MLOps).

**Tone:** Plain English, no jargon. Never show words like "index", "chunk", "embedding",
"schema", "MRR" or "candidate". Say "test version", "live version", "the chatbot found the
right document first for 92% of questions". Friendly and confident, like a good consumer app.

## Visual direction

- Clean, calm enterprise look: white and very light gray surfaces, one accent color, generous
  spacing, 8px radius cards, subtle borders instead of heavy shadows.
- Status colors only: green (good/live), amber (needs attention/test), red (blocked/failed),
  gray (draft/archived). Always pair color with an icon and a word.
- Desktop first (1280–1440 wide), responsive down to tablet. Chat must work on phone.
- Left sidebar navigation: Home, Create chatbot, Documents, Test questions, Launch, Chat,
  Admin (admins only). A chatbot picker at the top of the sidebar sets the current bot for
  Documents, Test questions and Launch.

## Shared components

- **Status pill:** Draft · Setting up · Setup failed · Testing · Waiting for approval · Live ·
  Paused · Paused (budget reached) · Archived.
- **Version chips:** "Live v7" (green) and "Test v8" (amber).
- **Readability badge** per document: Good (green) · Check it (amber) · Problem (red) · n/a for text files.
- **Progress checklist** for long jobs: step name, spinner/check/cross, plain-English error and a "Try again" button.
- **Metric tile:** big percentage, label in plain words, small "needs 90%" target, pass/fail icon.
- **Empty states** with one clear next action on every list.
- **Toasts** for saves; **confirm dialogs** for archive, rollback, approve.

## Screens

### 1. Home
- Greeting and a primary "Create a chatbot" button.
- Cards for each chatbot the user owns, reviews or tests: name, purpose (one line), status
  pill, version chips, questions this week, thumbs-up rate, month spend vs budget bar
  ($312 of $1,000), and a "needs you" badge (e.g. "3 documents to review", "Waiting for your
  approval", "Document expires in 12 days").
- "Needs your attention" list at top: approvals waiting, expiring documents, failed checks,
  budget at 70/90/100%.

### 2. Create chatbot (wizard, 6 steps, progress bar, Back/Next, autosaves as draft)
1. **Name and purpose:** chatbot name (shows the technical name live underneath and warns
   about duplicates), what it helps with (1–2 sentences), business function, team.
2. **People:** owner person (defaults to me), owner group, Reviewer (person or group who
   approves releases), testers (up to 10 emails, chips with a counter "3 of 10").
3. **Who can use it:** "People in my organization" (pick groups/people) or "Through another
   app" (only Public documents allowed; explain in one line). Channels: Chat page, API.
4. **Documents:** sensitivity (Public / Internal / Confidential with one-line explanations),
   source (upload files / git repository of markdown), expiry rule ("Documents expire on a
   date" vs "Valid until replaced by a newer version").
5. **Answers and safety:**
   - Answer style (short / detailed).
   - **Rules for every chatbot** (read-only, locked icon, "Set by MLOps"): do not give legal,
     medical, individual tax, investment or policy-coverage advice; do not explain how to make
     weapons, help with malicious cybersecurity, produce controlled substances or commit
     crimes; do not make high-stakes decisions; do not present itself as an authority.
     Owners cannot turn these off. No toggles for keyword blocking, advice disclaimers or
     competitor names.
   - Built-in protections (read-only list): harmful content filter, personal data masking,
     jailbreak blocking, hidden-instruction removal, exact source quotes, "I don't know" when
     documents don't say, conflict disclosure, no invented links.
   - **Add your own topics to refuse** (optional): an empty chip input. Nothing is
     pre-filled; owners can only add.
   - "Keep quoted text short" toggle (forced on, with the reason, for "Through another app").
   - Conversation memory: Off / This conversation only / Saved. Identity in logs: Named /
     Pseudonymous (Saved memory disabled when Pseudonymous, with the reason shown).
6. **Budget and review:** monthly budget (default $1,000), when reached: "Pause the chatbot"
   or "Keep running and alert me". Alerts: required ones listed as always on (outages,
   slowness, errors, budget, expiry); optional "Unusual traffic" toggle. Then a summary of all
   answers with Edit links and a big **Go** button.
- After Go: progress checklist (Creating workspace → Reading documents → Checking
  quality → Writing test questions → Choosing the best search method → First quality check),
  then lands on Documents.

### 3. Documents
- Upload area (drag and drop; PDF, Word, PowerPoint, images, markdown, text; max 100 MB /
  500 pages). Per upload: effective date, expiry date or "until replaced", page range
  (optional). Duplicate file → "Already uploaded" message. Same name → "Saved as version 3".
- Table: name, version, readability badge, status (Needs review / Approved / Flagged /
  Blocked: sensitive data / Archived), expires, owner, in test version (yes/no), in live (yes/no).
  Filters by status; search.
- **Review drawer/page** for one document: left = page image, right = extracted text for
  that page with its passages; page navigator; plain-English issues ("We couldn't read page
  4", "A table on page 2 may be scrambled"); buttons Approve, Flag passage, Re-read with
  different settings. Tabs: Review · Details (edit owner, dates, scopes without re-reading) ·
  History (versions, who approved, when).
- Actions: Archive (not delete), Restore, Download original, Upload new version.
- Banner when changes are waiting: "You have changes in the test version. Check and send for
  approval on the Launch page."

### 4. Test questions
- Tip banner: "Add a few questions of your own, the way real users would ask them."
- Editable table: question, expected answer, type (Should answer / Should refuse / From user
  feedback), difficulty (Easy / Hard), source document and page, approved checkbox, delete.
- Add row inline. Buttons: Suggest more questions, Run a check now.
- Counter and progress bar: "38 of 50 approved". **50 approved questions are required** to
  send for approval; the button stays disabled with that reason until then. Suggested
  questions are generated with ~30% extra so 50 survive review.

### 5. Launch (the release screen)
- Header: status pill, Live version chip, Test version chip.
- **Test version card:**
  - What changed since live (documents added/removed/updated, settings changed).
  - "How we search your documents": one sentence ("We tested 5 ways… 'Smart search with
    re-ranking' worked best: right document first for 92% of questions.").
  - Quality check: metric tiles in two groups. *Finding the right document:* first result,
    top 3, top 5, overall ranking. *Answer quality:* correct, sticks to sources, relevant,
    citations accurate, refuses correctly, safe. Each tile shows score and target.
    Hard failures listed in red ("1 answer cited the wrong page; this must be zero").
  - Safety review (Reviewer only, when flagged): list of flagged answers, required reason box,
    "Override and re-check".
  - Testers panel: chips, "3 of 10", add/remove.
  - Primary actions by role/state: Owner "Send for approval" (disabled with reason until the
    check passes); Reviewer "Approve and publish" / "Send back for changes" with comment.
  - After approve: progress (Publishing → Updating search → Smoke test) and outcome; if the
    smoke test fails: "We kept the previous version live" with details.
- **Live version card:** published date, approved by, document count, API snippet (copy
  button) when API is enabled, Pause/Resume, "Roll back to previous version" (confirm dialog
  naming the version it returns to).
- **Release history** timeline: version, date, approved by, check result, smoke test, rolled back?
- **Documentation:** auto-generated model card preview with Download.
- Archive chatbot (danger zone, confirm).

### 6. Chat
- Chatbot picker; for owners/Reviewer/testers a toggle "Live / Test version" with an amber
  test banner.
- Message list. Assistant messages show:
  - Small outcome label when not a normal answer: "Not covered by my documents", "Outside
    what I can help with", "No access", "Couldn't verify, showing sources".
  - Inline citation markers [1] [2] that highlight the matching source.
  - "Sources" section: document name, version, page(s), section, and the exact quoted
    excerpt in a quote block; link to open the document at that page.
  - Amber "Sources disagree" callout when documents conflict.
  - Thumbs up / down, with optional comment on down.
- "New conversation" button. Memory indicator: "Remembers this conversation" / "Doesn't
  remember earlier messages".

### 7. Admin (MLOps only)
- Tabs:
  - **Platform:** grouped forms for quality targets, models, pricing, monitoring thresholds
    (latency 5/12/20 s, error rate 5%, traffic window), retention (7 years), trusted
    middleware apps, synthetic callers, groups, and the **platform rules** list (edit text,
    add, remove for everyone). Save triggers a re-check of all chatbots.
  - **Chatbots:** table of all bots with state, owner, spend, critical flag, answer
    model, query rewrite toggle, platform pin, and "Platform rules turned off for this chatbot"
    (multi-select; admin only, recorded in the audit log and model card).
  - **User access:** CSV upload with preview and row count.
  - **Alerts:** open alerts with severity, chatbot, message, Resolve.
  - **Audit log:** searchable, filter by chatbot/actor/action.
  - **Re-index** after a reader change.

## States to design

Loading skeletons, empty lists, setup failed with retry, check running, check failed,
waiting for approval (owner view vs Reviewer view), live with test changes pending, paused
(budget), archived (read-only), no access.

## Data and actions (for developers)

| UI action | Backend |
|---|---|
| Go (wizard) | `ControlPlane.save_config` → provision job |
| Upload / new version / archive / restore / metadata edit / download | `Documents.register / archive / restore / update_metadata / download` → ingest job |
| Approve / flag document | `Documents.approve / flag` → ingest job (publish only) |
| Save test questions | `golden_set` table → ingest job (publish only) |
| Run a check | `run_evals` job, channel=candidate |
| Send for approval / send back | `releases.review_requested_at`, `set_state` |
| Approve and publish / roll back | `promote` job (action promote / rollback) |
| Pause / resume / archive | `ControlPlane.set_state` |
| Chat | serving endpoint `responses.create` with `custom_inputs` {bot_id, channel, conversation_id}; render `custom_outputs` {outcome, answer, citations[{n, doc_name, doc_version, pages, section, excerpt}], conflicts} |
| Thumbs | `feedback` table |
| Admin save | `ControlPlane.set_setting` → evals job for all bots |
