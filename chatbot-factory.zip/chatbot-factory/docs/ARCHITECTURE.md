# Architecture notes

Requirement IDs refer to the "Chatbot Builder App — Requirements" doc.

## Principles

- **Smallest working path.** One agent, one guardrailed endpoint, one AI Search endpoint,
  shared index. Pure logic lives in small modules with tests; jobs are thin scripts.
- **No warehouse in the hot path.** The agent reads bot config and settings from JSON in
  `<catalog>._platform.runtime` (written by the control plane on every change) and writes one
  JSON log per request to `<catalog>._platform.logs`. The monitor job loads logs with COPY INTO.
- **Unity Catalog decides access.** OBO callers are checked with a `SELECT` on the bot's
  `access_probe` (live) or `tester_probe` (test version). Trusted middleware service principals
  may assert `end_user`; anyone else asserting it is ignored.

## Releases (REL-*)

Index rows carry `in_live` and `in_candidate`. `Releases.stage` MERGEs the approved set into
the index source touching only changed rows, records `release_chunks`, snapshots and hashes.
`promote` flips flags (no re-embedding), `rollback` restores from `release_chunks`.
`index_history` is SCD2 so the index can be rebuilt for any day. Expiry and effective dates are
enforced at query time by filters, so nothing needs re-indexing when a document expires.

## Identity (IDN-*)

Named bots log the user. Pseudonymous bots log an HMAC pseudonym plus a Fernet-encrypted
identity; only Security holds the keys and can run `identity.decrypt_identity` (break-glass).

## Quality (EVL-*, EVG-*)

Golden sets mix easy questions and hard extraction questions (tables, footnotes, multi-page)
with expected pages. `compare_strategies` scores 5 retrieval strategies on Hit@k/MRR without
LLM calls and picks the best (ties → simpler). `run_evals` applies the combined gate.
Production judging samples 20% (100% for critical bots).

## Monitoring (OBS-*, CST-*, DCL-*)

App thread probes endpoint and index every 60 s (no compute). Hourly synthetic canary.
15-minute rollups drive latency (5/12/20 s), error rate (5%), availability, harmful output,
and optional traffic alerts within 8 AM ET – 6 PM PT. Budgets are computed from logged tokens
(shared endpoints can't be split by billing tags); alerts at 70/90/100%, owner picks pause or
continue. Expiry notices 30 days ahead. Alerts are rows in `alerts`, emailed by SQL alerts.

## Data model

Control plane `_platform`: settings, bots, bot_versions, releases, release_chunks, snapshots,
index_history, provisioning_steps, audit_log, shared_chunks, user_access, conversations,
request_log, guardrail_events, eval_runs, strategy_results, judge_results, feedback,
synthetic_health, monitoring_rollup, cost_daily, alerts, platform_releases; `v_*` views and
`*_redacted` views for Support.

Per bot: volume `docs`, `manifest`, `parsed_elements`, `chunked`, `index_source`
(Confidential), `golden_set`, `access_probe`, `tester_probe`.

Retention: 7 years (`jobs/maintenance.py`); `audit_log` is never purged.
