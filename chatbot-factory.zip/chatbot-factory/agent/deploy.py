"""Log, register and deploy the shared agent (ARC-1, CAS-2..6, ADM-1).

dev:  python deploy.py --catalog chatbots_dev --warehouse_id ... --endpoint chatbot-agent
prod: same with --require_gate true: refuses to deploy unless every live bot's
      golden set passed in dev against this platform version AND this exact git
      commit (CAS-4, REL-7). Every deployment is recorded in platform_releases.

Endpoint is always-on (no scale-to-zero) so non-technical users never wait on a
cold start. agents.deploy enables inference tables and MLflow tracing (MON-1).
"""
import argparse
import getpass
import sys
from pathlib import Path

import mlflow
from mlflow.models.auth_policy import AuthPolicy, SystemAuthPolicy, UserAuthPolicy
from mlflow.models.resources import (DatabricksServingEndpoint, DatabricksSQLWarehouse,
                                     DatabricksVectorSearchIndex)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from factory import PLATFORM_VERSION  # noqa: E402
from factory.config import PlatformSettings  # noqa: E402

p = argparse.ArgumentParser()
p.add_argument("--catalog", default="chatbots")
p.add_argument("--warehouse_id", required=True)
p.add_argument("--endpoint", default="chatbot-agent")
p.add_argument("--require_gate", default="false")
p.add_argument("--dev_catalog", default="")
p.add_argument("--git_commit", default="")
p.add_argument("--environment", default="dev")
p.add_argument("--identity_scope", default="chatbot-factory-identity")
p.add_argument("--agent_sp_scope", default="chatbot-factory")
a, _ = p.parse_known_args()

s = PlatformSettings.load({"catalog": a.catalog})
mlflow.set_registry_uri("databricks-uc")
model_name = f"{a.catalog}.{s.platform_schema}.chatbot_agent"

if a.require_gate == "true":
    from pyspark.sql import SparkSession
    spark = SparkSession.builder.getOrCreate()
    dev = a.dev_catalog or a.catalog
    failed = spark.sql(f"""
        WITH latest AS (
          SELECT bot_id, passed FROM `{dev}`.`{s.platform_schema}`.eval_runs
          WHERE platform_version = '{PLATFORM_VERSION}' AND git_commit = '{a.git_commit}'
          QUALIFY ROW_NUMBER() OVER (PARTITION BY bot_id ORDER BY ts DESC) = 1)
        SELECT b.bot_id FROM `{dev}`.`{s.platform_schema}`.bots b
        LEFT JOIN latest l USING (bot_id)
        WHERE b.state = 'live' AND b.deleted_at IS NULL
          AND (b.platform_pin IS NULL OR b.pin_expires_at < current_timestamp())
          AND NOT coalesce(l.passed, false)""").collect()
    if failed:
        raise SystemExit("Release gate failed (CAS-4) for: " + ", ".join(r.bot_id for r in failed))

resources = [
    DatabricksSQLWarehouse(warehouse_id=a.warehouse_id),
    DatabricksVectorSearchIndex(
        index_name=f"{a.catalog}.{s.platform_schema}.{s.get('ai_search.shared_index')}"),
    DatabricksServingEndpoint(endpoint_name=s.get("models.judge_endpoint")),
    *[DatabricksServingEndpoint(endpoint_name=e) for e in s.get("models.answer_endpoints").values()],
]
auth = AuthPolicy(
    system_auth_policy=SystemAuthPolicy(resources=resources),
    # On-behalf-of-user: the agent checks UC grants as the caller (GOV-4)
    user_auth_policy=UserAuthPolicy(api_scopes=["sql.statement-execution", "sql.warehouses"]),
)

with mlflow.start_run(run_name=f"chatbot_agent_{PLATFORM_VERSION}"):
    info = mlflow.pyfunc.log_model(
        name="agent",
        python_model=str(ROOT / "agent" / "agent.py"),
        code_paths=[str(ROOT / "src" / "factory")],
        auth_policy=auth,
        pip_requirements=[
            "mlflow>=3.4", "databricks-sdk>=0.60", "databricks-vectorsearch>=0.57",
            "databricks-ai-bridge>=0.6", "openai>=1.40", "pyyaml>=6", "cryptography>=42",
        ],
        registered_model_name=model_name,
        metadata={"platform_version": PLATFORM_VERSION},
    )

from databricks import agents  # noqa: E402

version = info.registered_model_version
sec = a.identity_scope
agents.deploy(
    model_name, version, endpoint_name=a.endpoint, scale_to_zero_enabled=False,
    environment_vars={
        "FACTORY_CATALOG": a.catalog, "FACTORY_WAREHOUSE_ID": a.warehouse_id,
        "FACTORY_ENV": a.environment, "FACTORY_GIT_COMMIT": a.git_commit,
        # IDN-2: pseudonym and break-glass keys from a Security-only secret scope
        "FACTORY_IDENTITY_HASH_KEY": f"{{{{secrets/{sec}/{s.get('access.identity_hash_key')}}}}}",
        "FACTORY_IDENTITY_ENCRYPTION_KEY": f"{{{{secrets/{sec}/{s.get('access.identity_encryption_key')}}}}}",
        # Dedicated agent service principal: reads the runtime volume, writes the logs volume
        "DATABRICKS_CLIENT_ID": f"{{{{secrets/{a.agent_sp_scope}/agent-sp-client-id}}}}",
        "DATABRICKS_CLIENT_SECRET": f"{{{{secrets/{a.agent_sp_scope}/agent-sp-client-secret}}}}",
    },
    tags={s.get("tags.chatbot_name"): s.get("tags.shared_value"),
          "platform_version": PLATFORM_VERSION},
)
from mlflow import MlflowClient  # noqa: E402
MlflowClient().set_registered_model_alias(model_name, "champion", version)

# Platform release record (REL-7, REL-8)
from pyspark.sql import SparkSession  # noqa: E402
SparkSession.builder.getOrCreate().sql(
    f"INSERT INTO `{a.catalog}`.`{s.platform_schema}`.platform_releases VALUES "
    "(uuid(), :pv, :gc, :env, :mv, :gate, :who, current_timestamp())",
    args={"pv": PLATFORM_VERSION, "gc": a.git_commit, "env": a.environment, "mv": str(version),
          "gate": a.require_gate == "true", "who": getpass.getuser()})
print(f"Deployed {model_name} v{version} to {a.endpoint} (platform {PLATFORM_VERSION})")
